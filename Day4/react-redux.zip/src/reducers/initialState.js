export default {
    count: 1,
    productsData: { products: [], status: "", flag: false }
}