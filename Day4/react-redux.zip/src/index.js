import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Router } from 'react-router-dom';
import history from './history';

import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';
import configureStore from './store/configureStore';
import { Provider } from 'react-redux';

// const appStore = configureStore({ counterReducer: 100 });
const appStore = configureStore();
// console.log(appStore.getState());

// ReactDOM.render(<Provider store={appStore}>
//     <BrowserRouter>
//         <RootComponent />
//     </BrowserRouter>
// </Provider>, document.getElementById('root'));

ReactDOM.render(<Provider store={appStore}>
    <Router history={history}>
        <RootComponent />
    </Router>
</Provider>, document.getElementById('root'));