import * as actionTypes from './actionTypes';

// Action Creator
export function incCounter(data = 1) {
    // Returns an Action Object
    return {
        type: actionTypes.INCREMENT_COUNTER,
        payload: data
    };
}

// Action Creator
export function decCounter(data = 1) {
    // Returns an Action Object
    return {
        type: actionTypes.DECREMENT_COUNTER,
        payload: data
    };
}

// Action Creator
export function mulCounter(data = 1) {
    // Returns an Action Object
    return {
        type: actionTypes.MULTIPLY_COUNTER,
        payload: data
    };
}