import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { flag: false, message: msg }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { flag: true, message: msg, data: products }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { flag: true, message: msg, data: [] }
    };
}

export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(function () {
                dispatch(loadProductsSuccess(products, "Request Completed..."));
            }, 1000);
        }).catch((eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

function insertProductsSuccess(product) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: product
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedProduct) => {
            dispatch(insertProductsSuccess(insertedProduct));
            history.push('/products');
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}

function updateProductsSuccess(product) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: product
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedProduct) => {
            dispatch(updateProductsSuccess(updatedProduct));
            history.push('/products');
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}

function deleteProductsSuccess(product) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: product
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductsSuccess(product));
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}