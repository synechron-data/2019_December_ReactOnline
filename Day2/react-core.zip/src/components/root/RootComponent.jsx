import React, { Component } from 'react';

import CounterAssignment from '../1_CounterAssignment';
import DataFlowAssignment from '../2_DataFlowAssignment';
import ControlledVsUncontrolled from '../3_ControlledVsUncontrolled';
import CalculatorAssignment from '../4_CalculatorAssignment';
import ListRoot from '../5_ListComponent';
import PropTypeRoot from '../6_PropTypes';
import AjaxComponent from '../7_AjaxComponent';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                {/* <CounterAssignment /> */}
                {/* <DataFlowAssignment /> */}
                {/* <ControlledVsUncontrolled /> */}
                {/* <CalculatorAssignment /> */}
                {/* <ListRoot /> */}
                {/* <PropTypeRoot /> */}
                <AjaxComponent />
            </div>
        );
    }
}

export default RootComponent;