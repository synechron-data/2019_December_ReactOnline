import React, { Component } from 'react';
import PropTypes from 'prop-types';

// const ListComponent = (props) => {
//     // console.log(props);
//     return (
//         <div>
//             {props.children}
//         </div>
//     );
// };

// const ListComponent = ({ children, items }) => {
//     var listItems = items.map((item, index, arr) => {
//         return <li key={item.id} className="list-group-item">{item.name}</li>;
//     });

//     // console.log(listItems);

//     return (
//         <div>
//             {children ? children : null}
//             <ul className="list-group">
//                 {listItems}
//             </ul>
//         </div>
//     );
// };

const ListItem = ({ item }) => {
    return <li className="list-group-item">{item.name}</li>;
}

const ListComponent = ({ children, items }) => {
    var listItems = items.map((item, index, arr) => {
        return <ListItem key={index} item={item} />
    });

    // console.log(listItems);

    return (
        <div>
            {children ? children : null}
            <ul className="list-group">
                {listItems}
            </ul>
        </div>
    );
};

ListComponent.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
}

class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        }
    }

    render() {
        return (
            <div>
                {/* <ListComponent items={this.state.employees}>
                    <h2 className="text-info">Employees List</h2>
                </ListComponent> */}

                <ListComponent items={[10, 20, 30, 40, 50]}>
                    <h2 className="text-info">Employees List</h2>
                </ListComponent>
            </div>
        );
    }
}

export default ListRoot;