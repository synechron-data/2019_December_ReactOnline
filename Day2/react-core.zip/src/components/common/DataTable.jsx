import React from 'react';
import PropTypes from 'prop-types';

const Ths = ({ item }) => {
    var ths = Object.keys(item).map((item, index) => {
        return <th key={index}>{item.toUpperCase()}</th>;
    });

    return (
        <tr>
            {ths}
        </tr>
    );
}

const Tds = ({ item }) => {
    var tds = Object.values(item).map((item, index) => {
        return <th key={index}>{item}</th>;
    });

    return (
        <tr>
            {tds}
        </tr>
    );
}

const DataTable = ({ items, children }) => {
    if (items && items.length) {
        var item = items[0];
        var ths = <Ths item={item} />;
        var tds = items.map((item, index) => {
            return <Tds key={index} item={item} />
        });
    }
    
    return (
        <div className="row mt-2">
            {children ? children : null}

            <table className="table table-hover">
                <thead>
                    {ths}
                </thead>
                <tbody>
                    {tds}
                </tbody>
            </table>
        </div>
    );
};

DataTable.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
}

export default DataTable;