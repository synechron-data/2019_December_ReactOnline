import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait.." };
        // this.handleClick = this.handleClick.bind(this);
    }

    // handleClick(e) {
    //     postAPIClient.getAllPosts().then((data) => {
    //         this.setState({ posts: data, message: "" });
    //     }).catch((eMsg) => {
    //         this.setState({ posts: [], message: eMsg });
    //     });
    // }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ posts: data, message: "" });
        }).catch((eMsg) => {
            this.setState({ posts: [], message: eMsg });
        });
    }

    render() {
        return (
            <React.Fragment>
                {/* <button className="btn btn-primary" onClick={this.handleClick}>Load Data</button> */}
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <DataTable items={this.state.posts}>
                    <h4 className="text-warning text-uppercase font-weight-bold">Posts Table</h4>
                </DataTable>
            </React.Fragment>
        );
    }
}

export default AjaxComponent;