import React, { Component } from 'react';
import EmployeesListComponent from './EmployeesListComponent';
import employeeAPIClient from '../../services/employee.service';
import { Link } from 'react-router-dom';

class EmployeesComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { employees: [] };
    }

    render() {
        return (
            <React.Fragment>
                <React.Fragment>
                    <div className="row mb-3">
                        <Link to={"/employee"}>Create Employee</Link>
                    </div>
                    <EmployeesListComponent employees={this.state.employees} />
                </React.Fragment>
            </React.Fragment>
        );
    }

    componentDidMount() {
        employeeAPIClient.getAllEmployees().then((result) => {
            this.setState({ employees: [...result] });
        }).catch((eMsg) => {

        })
    }
}

export default EmployeesComponent;