import React from 'react';
import { Link } from 'react-router-dom';

const EmployeesListComponent = ({ employees, onDelete }) => {
    return (
        <table className="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Salary</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                {
                    employees.map(employee =>
                        <EmployeeListRow onDelete={onDelete} employee={employee} key={employee.id} />)
                }
            </tbody>
        </table>
    );
};

const EmployeeListRow = ({ employee, onDelete }) => {
    return (
        <tr>
            <td>{employee.id}</td>
            <td>{employee.name}</td>
            <td>{employee.designation}</td>
            <td>{employee.salary}</td>
            <td>
                <Link className="text-info" to={"employee/" + employee.id}>Edit</Link>
            </td>
            <td>
                <Link className="text-danger" to={"employee/" + employee.id}>Delete</Link>
            </td>
        </tr>
    );
}

export default EmployeesListComponent;