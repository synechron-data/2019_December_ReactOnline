import React, { lazy, Suspense } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';

import authenticator from './services/authenticator.service';

import HomeComponent from './components/home/HomeComponent';
import EmployeesComponent from './components/employees/EmployeesComponent';

// Eager Loading
// import AboutComponent from './components/about/AboutComponent';
// import ProductComponent from './components/products/ProductComponent';
// import AdminComponent from './components/admin/AdminComponent';
// import LoginComponent from './components/login/LoginComponent';

// Lazy Loading
const AboutComponent = lazy(() => import('./components/about/AboutComponent'));
const ProductComponent = lazy(() => import('./components/products/ProductComponent'));
const AdminComponent = lazy(() => import('./components/admin/AdminComponent'));
const LoginComponent = lazy(() => import('./components/login/LoginComponent'));

const SecuredRoute = ({ component: Component, ...args }) => {
    return (
        <Route {...args} render={
            (props) => authenticator.isAuthenticated === true ? <Component {...props} /> :
                <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
        } />
    );
};

export default (
    <Suspense fallback={<div>Loading....</div>}>
        <Switch>
            <Route exact path="/" component={HomeComponent} />
            <Route path="/about" component={AboutComponent} />
            <Route path="/products" component={ProductComponent} />
            <SecuredRoute path="/admin" component={AdminComponent} />
            <Route path="/login" component={LoginComponent} />
            <Route path="/employees" component={EmployeesComponent} />
            <Route path="**" render={
                () => (
                    <article>
                        <h1 className="text-danger">No Route Configured!</h1>
                        <h4 className="text-danger">Please check your Route Configuration</h4>
                    </article>
                )
            } />
        </Switch>
    </Suspense>
);