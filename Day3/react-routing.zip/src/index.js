import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';

ReactDOM.render(<BrowserRouter>
    <RootComponent />
</BrowserRouter>, document.getElementById('root'));