import React, { Component } from 'react';
import Assignment from '../1_Assignment';
import ErrorHandler from '../common/ErrorHandler';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    <Assignment />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;