import React, { Component } from 'react';
import './ComponentOne.css';

class ComponentOne extends Component {
    render() {
        return (
            <h1 className="text-info card1">Hello from Component One</h1>
        );
    }
}

export default ComponentOne;