import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);
        return (
            <div>
                <h1 className="text-info">Using Class Syntax</h1>
            </div>
        );
    }
}

// Presentational (Stateless Components)
const ComponentTwo = () => {
    console.log("ComponentTwo", this);
    // console.log(this.state);
    // console.log(this.props);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

// Presentational (Stateless Components)
const ComponentThree = (props) => {
    console.log("ComponentThree", props);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentFour = ({ id, name }) => {
    console.log("ComponentFour", id, "\t", name);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentFive = ({ id, ...args }) => {
    console.log("ComponentFive", id);
    console.log("ComponentFive", args);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

class ClassVsFunctional extends Component {
    render() {
        return (
            <div>
                <ComponentOne />
                <ComponentTwo />
                <ComponentThree id={1} name={"Manish"} city={"Pune"} state={"MH"} />
                <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} />
                <ComponentFive id={1} name={"Manish"} city={"Pune"} state={"MH"} />
            </div>
        );
    }
}

export default ClassVsFunctional;