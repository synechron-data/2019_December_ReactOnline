import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);

        // this.props.name = "Abhijeet";
        // this.state = this.props;
        // this.state.name = "Abhijeet";

        // Shallow Copy
        // this.state = Object.assign({}, this.props);
        // this.state = {...this.props};
        // this.state.name = "Abhijeet";
        // this.state.address.city = "Mumbai";

        // Deep Copy - Will remove all functions from props
        this.state = JSON.parse(JSON.stringify(this.props));
        this.state.name = "Abhijeet";
        this.state.address.city = "Mumbai";

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);

        return (
            <div>
                <h2 className="text-info">Hello, {this.props.name}</h2>
                <h2 className="text-info">Hello, {this.state.name}</h2>
            </div>
        );
    }
}

export default ComponentWithProps;