// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // Can Return Primitive Type
//         // return "Hello";        
//         // return 12;       
//         // return true;

//         // Cannot return Objects
//         // return { id: 1, name: "Manish" };

//         // return <h1 className="card">Hello World</h1>;

//         // return (
//         //     <div>
//         //         <h1 className="card">Hello World</h1>
//         //         <h1 className="card">Hello World Again</h1>
//         //     </div>
//         // );

//         return (
//             <React.Fragment>
//                 <h1 className="card">Hello World</h1>
//                 <h1 className="card">Hello World Again</h1>
//             </React.Fragment>
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------

// import React, { Component, Fragment } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <Fragment>
//                 <h1 className="card">Hello World</h1>
//                 <h1 className="card">Hello World Again</h1>
//             </Fragment>
//         );
//     }
// }

// export default HelloComponent;

// // ------------------------------------------------ Functional Components

// import React from 'react';

// // function HelloComponent() {
// //     return (
// //         <React.Fragment>
// //             <h1 className="card">Hello World</h1>
// //             <h1 className="card">Hello World Again</h1>
// //         </React.Fragment>
// //     );
// // }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1 className="card">Hello World</h1>
//             <h1 className="card">Hello World Again</h1>
//         </React.Fragment>
//     );
// }

// export default HelloComponent;

// --------------------------------------------- Arrow Functions (Functional Components)
import React from 'react';

// const HelloComponent = () => {
//     return (
//         <React.Fragment>
//             <h1 className="card">Hello World</h1>
//             <h1 className="card">Hello World Again</h1>
//         </React.Fragment>
//     );
// }

const HelloComponent = () => (
    <React.Fragment>
        <h1 className="card">Hello World</h1>
        <h1 className="card">Hello World Again</h1>
    </React.Fragment>
);

export default HelloComponent;