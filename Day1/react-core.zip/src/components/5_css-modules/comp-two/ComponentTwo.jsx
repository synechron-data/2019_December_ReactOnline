import React, { Component } from 'react';
import styles from './ComponentTwo.module.css';

class ComponentTwo extends Component {
    render() {
        return (
            <h1 className={`text-success ${styles.card}`}>Hello from Component Two</h1>
        );
    }
}

export default ComponentTwo;